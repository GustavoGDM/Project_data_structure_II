#ifndef NETWORK_H_INCLUDED
#define NETWORK_H_INCLUDED

#include"insertNetwork.c"
#include"InitializeNetwork.c"
#include"excludeNetwork.c"
#include"BSF.c"
#include"DSF.c"
#include"handleNetwork.c"


#endif // NETWORK_H_INCLUDED
