#ifndef FILES_H_INCLUDED
#define FILES_H_INCLUDED

#include"handlefiles.c"
#include"Initializefiles.c"

#endif // FILES_H_INCLUDED